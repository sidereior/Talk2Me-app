//
//  ContentView.swift
//  Shared
//
//  Created by Alexander Nanda on 6/8/21.
//

import SwiftUI

struct TabItem {
    
}

struct ContentView: View {
  
    @State var presented=false
    @State var selectedIndex = 0
    
    let icons = [
        "house",
        "plus",
        "gear"
    ]
    
    var body: some View {
        
            
                VStack {
                    //tab bar
                    ZStack{
                        HStack{
                        Spacer().fullScreenCover(isPresented: $presented, content: {
                            
                            Button(action: {
                                presented.toggle()
                            }, label: {
                                Text("Exit Edit Screen")
                                    .frame(width: 200, height: 50)
                                    .background(Color.pink)
                                    .cornerRadius(12)
                                
                            })
                                
                        })
                            
                        }
                        
                        
                        switch selectedIndex {
                        case 0:
                            HomeView()
                        case 1:
                            NavigationView{
                                VStack{
                                    Text("Edit Screen")
                                }
                                .navigationTitle("Edit")
                            }
                        default:
                            NavigationView{
                                VStack{
                                    Text("Settings Screen")
                                }
                                .navigationTitle("Settings")
                            }
                        }
                    }
                    Spacer()
                    
                    Divider()
                        .padding(.bottom, 20)
                    HStack
                    {
                        ForEach(0..<3, id: \.self){ number in
                            Spacer()
                            Button(action: {
                                if number == 1 {
                                    presented.toggle()
                                }
                            }, label: {
//                                Image(systemName: icons[number])
//                                    .font(.system(size:25,
//                                                  weight: .regular,
//                                                  design: .default
//                                                    ))
//                                    .foregroundColor(selectedIndex == number ? .black: Color(UIColor.lightGray))
                                //ignore that i think we need to keep it for now becuase i have a feeling that when you will try to add in popups the preformance will be terrible and overlay might not work and i think we may need ot switch back to this later
                                if number == 1 {
                                    Image(systemName: icons[number])
                                        .font(.system(size:25,
                                                      weight: .regular,
                                                      design: .default
                                                        ))
                                        .foregroundColor(.white)
                                        .frame(width: 60, height: 60)
                                        .background(Color.blue)
                                        .cornerRadius(30)
                                }
                                else {
                                    Image(systemName: icons[number])
                                        .font(.system(size:25,
                                                      weight: .regular,
                                                      design: .default
                                                        ))
                                        .foregroundColor(selectedIndex == number ? Color(.label) : Color(UIColor.lightGray))
                                }
                                })
                            Spacer()
                        }
                        
                    }
//                    ForEach(0..<3) { _ in
//                        Button {
//
//                        } label: {
//                            Image("logo")
//                                .resizable()
//                                .aspectRatio(contentMode: .fit)
//                                .padding()
//                        }
//                    }
//                }
            }
        
}

    struct HomeView: View {
        var body: some View{
            NavigationView{
                VStack{
                    Text("First Home Screen")
                }
                .navigationTitle("Home")
            }
        }
    }
    
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .preferredColorScheme(.dark)
    }
}

}
