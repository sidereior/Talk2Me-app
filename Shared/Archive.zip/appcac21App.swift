//
//  appcac21App.swift
//  Shared
//
//  Created by Alexander Nanda on 6/8/21.
//

import SwiftUI

@main
struct appcac21App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
